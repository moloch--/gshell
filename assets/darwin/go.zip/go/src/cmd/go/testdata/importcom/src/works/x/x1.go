package x // important! not an import comment
