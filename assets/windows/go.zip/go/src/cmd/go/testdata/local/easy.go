package main

import "./easysub"

func main() {
	easysub.Hello()
}
